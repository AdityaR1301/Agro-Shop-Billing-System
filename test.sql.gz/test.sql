-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2020 at 03:27 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `BNo` int(11) NOT NULL,
  `CId` int(11) DEFAULT NULL,
  `PId` int(11) DEFAULT NULL,
  `Date` varchar(20) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `Total` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`BNo`, `CId`, `PId`, `Date`, `Quantity`, `Total`) VALUES
(1, 2, 5, '09/03/2020', 10, 4700),
(2, 2, 6, '09/03/2020', 10, 10000),
(3, 2, 3, '09/03/2020', 10, 13000),
(4, 2, 6, '09/03/2020', 10, 6300),
(5, 2, 3, '09/03/2020', 10, 3000);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `CId` int(11) NOT NULL,
  `CName` varchar(20) NOT NULL,
  `CAddr` varchar(20) NOT NULL,
  `CMbNo` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`CId`, `CName`, `CAddr`, `CMbNo`) VALUES
(1, 'Aditya Ranaware', 'Shindewadi', '8484865030'),
(2, 'Sachin Ghadage', 'Satara', '9146435251');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user` varchar(20) NOT NULL,
  `pass` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mob` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user`, `pass`, `email`, `mob`) VALUES
('Aditya', '1301', 'adityaranaware1301@g', '8484865030');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `PId` int(10) NOT NULL,
  `PName` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `quantity` int(10) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PId`, `PName`, `Type`, `quantity`, `price`) VALUES
(1, 'Magnesium Sulphate', 'Fertilizer', 50, 800),
(2, 'Ammonium Sulphate', 'Fertilizer', 50, 800),
(3, 'Urja Watermelon', 'seed', 10, 1000),
(4, 'Custard Apple', 'seed', 10, 1500),
(5, 'Agro plus(100ml)', 'pesticide', 10, 100),
(6, 'Admire(100 ml)', 'pesticide', 10, 750);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `rno` int(11) NOT NULL,
  `name` char(20) NOT NULL,
  `percentage` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`rno`, `name`, `percentage`) VALUES
(1, 'aditya', 85);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`BNo`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`CId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
